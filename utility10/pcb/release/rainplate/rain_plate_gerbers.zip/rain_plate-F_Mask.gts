%TF.GenerationSoftware,KiCad,Pcbnew,7.0.11+dfsg-1build4*%
%TF.CreationDate,2026-10-31T18:50:49+00:00*%
%TF.ProjectId,rain_plate,7261696e-5f70-46c6-9174-652e6b696361,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 7.0.11+dfsg-1build4) date 2026-10-31 18:50:49*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11O,1.700000X1.700000*%
G04 APERTURE END LIST*
D10*
%TO.C,J1*%
X18000000Y-50000000D03*
D11*
X18000000Y-52540000D03*
%TD*%
M02*
